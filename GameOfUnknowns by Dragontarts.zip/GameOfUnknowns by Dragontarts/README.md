
# Trivia Game 
Implementation of the Hangman game in Java & JavaFX
## ▶ Demo  
![](https://github.com/BrachiFrenkel/Trivia/blob/main/trivia.gif)
## 💻 How To Play?
* clone the repository
* run Main.java
* play and enjoy!
