package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class QuestionBankForGOU {
    private ArrayList<QuestionsForGOU> gouQuestions = new ArrayList<>(); // The list of questions

	public QuestionBankForGOU(String fileName) throws FileNotFoundException {
        try (Scanner fileReader = new Scanner(new File(fileName))) {
            // Read the file line by line
            while (fileReader.hasNextLine()) {
                String question = fileReader.nextLine();
                String correctAnswer = fileReader.nextLine();
                ArrayList<String> possibleAnswers = new ArrayList<>();
                // Read the possible answers
                
              
                for (int i = 0; i < 3; i++) {
                    possibleAnswers.add(fileReader.nextLine());
                }
                
                // add also the correct answer
             
                possibleAnswers.add(correctAnswer);
                // Add the question to the list

                gouQuestions.add(new QuestionsForGOU(question, correctAnswer, possibleAnswers));
            }
        }
        
        String newQuestion = "What is the name of Boston's oldest public park?";
        String newCorrectAnswer = "Boston Common";
        ArrayList<String> newPossibleAnswers = new ArrayList<>();
        newPossibleAnswers.add("The Rose Kennedy Greenway");
        newPossibleAnswers.add("The Arnold Arboretum");
        newPossibleAnswers.add(newCorrectAnswer);
        newPossibleAnswers.add("Franklin Park");
        gouQuestions.add(new QuestionsForGOU(newQuestion, newCorrectAnswer, newPossibleAnswers));  
        
        
        String newQuestion2 = "What is the name of the famous Boston marathon?";
        String newCorrectAnswer2 = "The Boston Marathon";
        ArrayList<String> newPossibleAnswers2 = new ArrayList<>();
        newPossibleAnswers2.add("The Patriot's Run");
        newPossibleAnswers2.add(newCorrectAnswer2);
        newPossibleAnswers2.add("The Red Sox Run");
        newPossibleAnswers2.add("The Boston Run");
        
        gouQuestions.add(new QuestionsForGOU(newQuestion2, newCorrectAnswer2, newPossibleAnswers2));
        
        String newQuestion3 = "Which university is located in Boston's Fenway neighborhood?";
        String newCorrectAnswer3 = "Northeastern University";
        ArrayList<String> newPossibleAnswers3 = new ArrayList<>();
        newPossibleAnswers3.add("Boston College");
        newPossibleAnswers3.add(newCorrectAnswer3);
        newPossibleAnswers3.add("Boston University");
        newPossibleAnswers3.add("Harvard University");
        
        gouQuestions.add(new QuestionsForGOU(newQuestion3, newCorrectAnswer3, newPossibleAnswers3));
        
        String newQuestion4 = "What is the name of Boston's iconic, green-colored subway line?";
        String newCorrectAnswer4 = "The Green Line";
        ArrayList<String> newPossibleAnswers4 = new ArrayList<>();
        newPossibleAnswers4.add(newCorrectAnswer4);
        newPossibleAnswers4.add("The Blue Line");
        newPossibleAnswers4.add("The Orange Line");
        newPossibleAnswers4.add("The Red Line");
        
        gouQuestions.add(new QuestionsForGOU(newQuestion4, newCorrectAnswer4, newPossibleAnswers4));
        
        String newQuestion5 = "What is the name of the famous ballpark where the Boston Red Sox play?";
        String newCorrectAnswer5 = "Fenway Park";
        ArrayList<String> newPossibleAnswers5 = new ArrayList<>();
        newPossibleAnswers5.add("Wrigley Field");
        newPossibleAnswers5.add(newCorrectAnswer5);
        newPossibleAnswers5.add("Dodger Stadium");
        newPossibleAnswers5.add("Yankee Stadium");
        
        gouQuestions.add(new QuestionsForGOU(newQuestion5, newCorrectAnswer5, newPossibleAnswers5));
        
        String newQuestion6 = "Which historic event took place in Boston on December 16, 1773?";
        String newCorrectAnswer6 = "The Boston Tea Party";
        ArrayList<String> newPossibleAnswers6 = new ArrayList<>();
        newPossibleAnswers6.add("The signing of the Declaration of Independence");
        newPossibleAnswers6.add(newCorrectAnswer6);
        newPossibleAnswers6.add("The Boston Massacre");
        newPossibleAnswers6.add("The Siege of Boston");
        
        gouQuestions.add(new QuestionsForGOU(newQuestion6, newCorrectAnswer6, newPossibleAnswers6));
        
        String newQuestion7 = "What is the name of the famous shopping street in downtown Boston?";
        String newCorrectAnswer7 = "Newbury Street";
        ArrayList<String> newPossibleAnswers7 = new ArrayList<>();
        newPossibleAnswers7.add(newCorrectAnswer7);
        newPossibleAnswers7.add("Fifth Avenue");
        newPossibleAnswers7.add("Rodeo Drive");
        newPossibleAnswers7.add("Michigan Avenue");
        
        gouQuestions.add(new QuestionsForGOU(newQuestion7, newCorrectAnswer7, newPossibleAnswers7));
        
        
        
        
        
        
        
    }

    public List<QuestionsForGOU> getGouQuestions() {
        return gouQuestions;
    }

    public String getQuestion(int index) {
        return gouQuestions.get(index).getQuestion();
    }

    public String getCorrectAnswer(int index) {
        return gouQuestions.get(index).getCorrectAnswer();
    }

    public ArrayList<String> getPossibleAnswers(int index) {
        return new ArrayList<>(gouQuestions.get(index).getPossibleAnswers());
    }

    public int getNumberOfQuestions() {
        return gouQuestions.size();
    }

    public void removeQuestion(int index) {
        gouQuestions.remove(index);
    }

	
}
