package application;

import java.util.ArrayList;

public class QuestionsForGOU {
    private final String question;
    private final String correctAnswer;
    private final ArrayList<String> possibleAnswers;

    public QuestionsForGOU(String question, String correctAnswer, ArrayList<String> possibleAnswers) {
        this.question = question;
        this.correctAnswer = correctAnswer;
        this.possibleAnswers = possibleAnswers;
    }

    // Getters
    public String getQuestion() {
        return question;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public ArrayList<String> getPossibleAnswers() {
        return new ArrayList<>(possibleAnswers);
    }
}
