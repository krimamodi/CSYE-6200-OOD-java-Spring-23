package application;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;


import static javafx.application.Platform.exit;

public class ControllerForGOU implements Initializable {

    @FXML
    private Label questionLbl;

    @FXML
    private Button exitBtn;

    @FXML
    private Button newGameBtn;

    @FXML
    private AnchorPane optionPane;

    @FXML
    private Label scoreLbl;

    @FXML
    private Button endGameBtn;

    @FXML
    private Button nextBtn;

    @FXML
    private Label gameOverLbl;

    @FXML
    private Label winLbl;

    @FXML
    private ImageView backgroundImg;

    private GameOfUnknowns game;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        startGame();
    }

    private void startGame() {
        game = new GameOfUnknowns();
        backgroundImg.setImage(new Image("file:/Users/keerthanapanyam/Downloads/GameOfUnknowns copy K/MediaForGOU/background.jpg"));
        setStartScreen();
        questionLbl.setWrapText(true);
        questionLbl.setText(game.askQuestion());
        game.shufflePossibleAnswers();
        setAnswersToScreen();
    }

    private void setStartScreen() {
        winLbl.setVisible(false);
        scoreLbl.setVisible(true);
        questionLbl.setVisible(true);
        exitBtn.setVisible(false);
        newGameBtn.setVisible(true);
        endGameBtn.setVisible(true);
        nextBtn.setVisible(true);
        optionPane.setVisible(true);
        optionPane.setDisable(false);
        resetOptions();
        exitBtn.setVisible(false);
        newGameBtn.setVisible(false);
        scoreLbl.setText("score:\n" + game.getScore());
    }

//    private void setAnswersToScreen() {
//        for (Node lbl : optionPane.getChildren()) {
//            ((Label) lbl).setText(game.getPossibleAnswers().get(optionPane.getChildren().indexOf(lbl)));
//        }
//       
//    }
    
    private void setAnswersToScreen() {
        game.shufflePossibleAnswers(); // Shuffle the list of possible answers
        List<String> possibleAnswers = game.getPossibleAnswers(); // Get the shuffled list
        for (Node lbl : optionPane.getChildren()) {
            ((Label) lbl).setText(possibleAnswers.get(optionPane.getChildren().indexOf(lbl)));
        }
    }
    
    
    

//    private void setAnswersToScreen() {
//    	 List<String> possibleAnswers = game.getPossibleAnswers();
//    	    game.shufflePossibleAnswers();
//    	    for (int i = 0; i < optionPane.getChildren().size(); i++) {
//    	        Label label = (Label) optionPane.getChildren().get(i);
//    	        label.setText(possibleAnswers.get(i));
//    	    }
//    	    
//    	    System.out.println("dISPLAYED list of possible answers: " + possibleAnswers);
//    }
//    
    
    
    @FXML
    void chooseOptionLblOnAction(MouseEvent event) {
        String selectedAnswer = ((Label)event.getSource()).getText();
        if (game.isCorrectAnswer(selectedAnswer)) {
            game.updateScore(game.CORRECT_ANSWER_SCORE);
            scoreLbl.setText("score:\n" + game.getScore());
            ((Label) event.getSource()).setStyle("-fx-background-radius: 10px; -fx-border-color: white; -fx-border-width: 1px; -fx-border-radius: 10px; -fx-background-color: #4cb051;");
            Media sound = new Media(new File("SoundForGOU/goodSound.mp3").toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(sound);
            mediaPlayer.play();
        } else {
            game.updateScore(game.WRONG_ANSWER_SCORE);
            scoreLbl.setText("score:\n" + game.getScore());
            ((Label) event.getSource()).setStyle("-fx-background-radius: 10px; -fx-border-color: white; -fx-border-width: 1px; -fx-border-radius: 10px; -fx-background-color: #ec4352;");
            Media sound = new Media(new File("SoundForGOU/badSound.mp3").toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(sound);
            mediaPlayer.play();
        }
        for (Node lbl : optionPane.getChildren()) {
            lbl.setDisable(true);
        }
        game.removeQuestion(game.getCurrentQuestionIndex());
        return;
    }

    @FXML
    void nextQuestionOnAction(ActionEvent event) {
        resetOptions();
        if(game.getNumberOfQuestions() > 0) {
            questionLbl.setWrapText(true);
            questionLbl.setText(game.askQuestion());
            // shuffle the possible answers
            game.shufflePossibleAnswers();
            // set the buttons with the possible answers
            for (Node option: optionPane.getChildren()){
                ((Label) option).setText(game.getPossibleAnswers().get(optionPane.getChildren().indexOf(option)));
            }
        } else {
            setFinishScreen();
        }


    }

    @FXML
    void endGameOnAction(ActionEvent event) {
        setFinishScreen();
    }

    private void setFinishScreen() {
        winLbl.setVisible(true);
        // System.out.println("Working Directory = " + System.getProperty("user.dir"));

        winLbl.setGraphic(new ImageView(new Image("file:/Users/keerthanapanyam/Downloads/GameOfUnknowns copy K/MediaForGOU/victory.gif")));
        winLbl.setVisible(true);
        gameOverLbl.setVisible(true);
        gameOverLbl.setText("GAME OVER!\nYour score is: " + game.getScore() );
        scoreLbl.setVisible(false);
        questionLbl.setVisible(false);
        exitBtn.setVisible(true);
        newGameBtn.setVisible(true);
        endGameBtn.setVisible(false);
        nextBtn.setVisible(false);
        optionPane.setVisible(false);
        optionPane.setDisable(true);

    }

    @FXML
    void exitOnAction(ActionEvent event) {
        exit();
    }


    @FXML
    void newGameOnAction(ActionEvent event) {
        for (Node option: optionPane.getChildren()){
            ((Label) option).setDisable(false);
        }
        gameOverLbl.setVisible(false);
        scoreLbl.setVisible(true);
        questionLbl.setVisible(true);
        winLbl.setVisible(false);
        optionPane.setVisible(true);
        startGame();



    }


    public void resetOptions() {
        for (Node option: optionPane.getChildren()){
            option.setDisable(false);
            option.setDisable(false);
            ((Label) option).setStyle("-fx-background-radius: 10px; -fx-background-color: transparent; -fx-border-color: white; -fx-border-width: 1px; -fx-border-radius: 10px;");
        }
    }



}

