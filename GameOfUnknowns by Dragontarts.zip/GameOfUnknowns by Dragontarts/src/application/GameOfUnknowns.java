package application;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class GameOfUnknowns {
    public static final String FILE_NAME = "src/gou.txt";
    public static final int CORRECT_ANSWER_SCORE = 10;
    public static final int WRONG_ANSWER_SCORE = -5;
    private QuestionBankForGOU gouQuestions;
    private int currentQuestionIndex = 0;
    private int score = 0;

    public GameOfUnknowns() {
        try {
            gouQuestions = new QuestionBankForGOU(FILE_NAME);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

   

//       public GameOfUnknowns() {
//            gouQuestions = new QuestionBankForGOU();
//        }
//    
    
    
    public boolean isCorrectAnswer(String answer) {
        return gouQuestions.getCorrectAnswer(currentQuestionIndex).equals(answer);
    }

   public void shufflePossibleAnswers() {
       Collections.shuffle(gouQuestions.getPossibleAnswers(currentQuestionIndex));
    }

//   public void shufflePossibleAnswers() {
//	    ArrayList<String> possibleAnswers = gouQuestions.getPossibleAnswers(currentQuestionIndex);
//	    System.out.println("Original list of possible answers: " + possibleAnswers);
//	    Collections.shuffle(possibleAnswers);
//	    System.out.println("Shuffled list of possible answers: " + possibleAnswers);
//	    int correctAnswerIndex = possibleAnswers.indexOf(gouQuestions.getCorrectAnswer(currentQuestionIndex));
//	    System.out.println("Index of correct answer: " + correctAnswerIndex);
//	}
    public String askQuestion() {
        currentQuestionIndex = chooseRandomQuestion();
        return gouQuestions.getQuestion(currentQuestionIndex);
    }

    public int chooseRandomQuestion() {
        return new Random().nextInt(gouQuestions.getNumberOfQuestions());
    }

    public void updateScore(int i) {
        score += i;
    }

    public int getCurrentQuestionIndex() {
        return currentQuestionIndex;
    }

    public void removeQuestion(int currentQuestionIndex) {
        gouQuestions.removeQuestion(currentQuestionIndex);
    }

    public int getNumberOfQuestions() {
        return gouQuestions.getNumberOfQuestions();
    }

    public ArrayList<String> getPossibleAnswers() {
        return gouQuestions.getPossibleAnswers(currentQuestionIndex);
    }

    public int getScore() {
        return score;
    }
}
